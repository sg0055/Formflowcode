# FormFlow (Chrome Extension)

Professional data entry automation with visual field mapping and auto-pilot mode. Upload data (CSV/XLSX/DOCX), visually map columns to form fields, and automate form submissions.

## Project structure

```
FormFlow/
├── manifest.json              # MV3 extension config
├── popup/
│   ├── index.html             # Main UI with 5 tabs
│   ├── popup.css              # Custom styles
│   ├── popup.js               # Tab logic, file handling, storage
│   └── tailwind.css           # Optimized Tailwind utilities
├── content/
│   └── content.js             # Visual picker, autofill engine (694 lines)
├── background/
│   └── background.js          # Service worker (minimal)
├── lib/
│   ├── helpers.js             # CSV/XLSX/DOCX parsers, StorageManager
│   ├── xlsx.full.min.js       # SheetJS (required - manually add)
│   └── mammoth.browser.min.js # Mammoth.js (required - manually add)
├── icons/
│   ├── icon16.png             # Toolbar icon (16×16)
│   ├── icon48.png             # Menu icon (48×48)
│   └── icon128.png            # Store icon (128×128) ✓ Real PNGs
```

## ✅ Features Implemented

### Upload Tab
- Drag-and-drop file upload zone with visual feedback
- Support for `.csv`, `.xlsx`, `.xls`, `.docx` files
- CSV parser with proper quote/comma handling
- Excel parsing via SheetJS library
- Word document table extraction via Mammoth.js
- Live data preview table (first 15 rows)
- File stats display (row count, column count)

### Mapping Tab
- **Visual Picker Mode:** Click "Start Visual Picker" to highlight fields on any webpage
- SmartSelector generation: name → id → classes → tag fallback
- SmartLabel detection: 7-level fallback (label[for], wrapper, sibling, aria-label, placeholder, etc.)
- Floating panel UI with column assignment
- Mapping counter badge
- Save mappings as templates
- Auto-Detect Fields button (scans all inputs on page)

### Templates Tab
- Load and apply saved mapping templates
- Template management with timestamps
- Export/Import all templates as JSON

### Auto-Pilot Tab
- Row-by-row manual review mode with← → navigation
- Jump-to-row input for quick navigation
- Configurable delay before form submission (0.5–10 sec)
- Max rows limiter (0 = all rows)
- Clear form button for resetting between rows
- Full automation mode with progress tracking

### Settings Tab
- Auto-submit checkbox
- Header detection toggle
- JSON export/import backup for all data and templates
- Data persistence via `chrome.storage.sync` (100KB quota)

### Architecture
- **MV3 manifest** with proper permissions and icons
- **Content script messaging** (popup ↔ active tab)
- **Popup-to-content bridge** for visual mapping
- **Chrome storage sync** for templates & site mappings
- **Robust error handling** in file parsing

## Installation (Chrome/Edge)

1. Open `chrome://extensions` (or `edge://extensions` for Edge)
2. Enable **Developer mode** (toggle in top-right)
3. Click **Load unpacked**
4. Select the `FormFlow` project folder
5. Extension appears with violet icon in toolbar ✓

### ⚠️ Required: Add External Libraries

Before loading the extension, you **must** add two libraries to `/lib/`:

1. **SheetJS (xlsx)**
   - Download: https://github.com/SheetJS/sheetjs/releases
   - Get: `xlsx.full.min.js`
   - Place in: `lib/xlsx.full.min.js`

2. **Mammoth.js**
   - Download: https://github.com/mwilson/mammoth.js/releases
   - Get: `mammoth.browser.min.js`
   - Place in: `lib/mammoth.browser.min.js`

Without these, file parsing will fail silently.

## Usage

### Basic Workflow

1. **Upload Data**
   - Click extension icon → Upload tab
   - Drag CSV/XLSX/DOCX file or click zone
   - Preview table loads automatically

2. **Map Fields**
   - Click "Start Visual Picker"
   - Hover form fields (they'll highlight in violet)
   - Click a field → floating panel shows
   - Select matching data column → "Map Data"
   - Repeat for all required fields
   - Or click "Auto-Detect Fields" to autodiscover page fields

3. **Save Template** (Optional)
   - After mapping all fields, click "Save Mappings as Template"
   - Enter template name (e.g., "MyForm_v1")
   - Next time on same site, load template instead of re-mapping

4. **Run Auto-Filler**
   - Click Auto-Pilot tab
   - Set delay (default 2 sec between rows)
   - Set max rows (0 = all)
   - Click "▶ Start Auto-Pilot"
   - Extension fills forms row-by-row, submits after each row

