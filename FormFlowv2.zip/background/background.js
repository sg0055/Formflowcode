// background/background.js

chrome.runtime.onInstalled.addListener(() => {
  console.log("FormFlow installed successfully.");
  // FUTURE: Initialize default settings in chrome.storage.sync
  // chrome.storage.sync.set({ templates: [], defaultDelay: 1500 });
});

// FUTURE: Handle background tasks if we implement multi-tab auto-advance 
// or need to listen to page reloads during the auto-submit loop.