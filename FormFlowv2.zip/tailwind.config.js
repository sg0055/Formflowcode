/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./popup/**/*.{html,js}"], // Scans your popup HTML and JS files
  theme: {
    extend: {},
  },
  plugins: [],
}