﻿// ==========================================
// 1. SAFE VARIABLE INITIALIZATION
// ==========================================
if (typeof isMappingMode === 'undefined') {
    var isMappingMode = false;
    var isPanelOpen = false;
    var currentHeaders = [];
    var hoveredElement = null;
    var targetSelector = '';
    var targetLabel = '';
    console.log("FormFlow Content Script Initialized.");
}

// ==========================================
// 2. UI & CSS INJECTION
// ==========================================
var injectStyles = () => {
    if (document.getElementById('ff-styles')) return;
    var style = document.createElement('style');
    style.id = 'ff-styles';
    style.innerHTML = `
        .ff-highlight {
            outline: 3px solid #8b5cf6 !important;
            outline-offset: 2px !important;
            background-color: rgba(139, 92, 246, 0.1) !important;
            cursor: crosshair !important;
            transition: all 0.2s ease !important;
        }
        #ff-floating-panel {
            position: absolute; z-index: 2147483647; background: white;
            border: 1px solid #e2e8f0; border-radius: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            padding: 12px; font-family: system-ui, -apple-system, sans-serif;
            width: 250px; display: none; cursor: default;
        }
        #ff-floating-panel p { margin: 0 0 8px 0; font-size: 12px; color: #64748b; font-weight: 600; }
        #ff-floating-panel select { 
            width: 100%; padding: 6px; border: 1px solid #cbd5e1; 
            border-radius: 4px; margin-bottom: 8px; font-size: 13px; cursor: pointer;
        }
        .ff-btns { display: flex; gap: 8px; margin-bottom: 8px; }
        .ff-btns button { flex: 1; padding: 6px; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500; transition: background 0.1s; }
        #ff-btn-save { background: #8b5cf6; color: white; }
        #ff-btn-save:hover { background: #7c3aed; }
        #ff-btn-cancel { background: #e2e8f0; color: #475569; }
        #ff-btn-cancel:hover { background: #cbd5e1; }
        
        #ff-btn-submit-map {
            width: 100%; padding: 8px; border: none; border-radius: 4px;
            background: #f59e0b; color: white; font-weight: bold;
            font-size: 12px; cursor: pointer; transition: background 0.1s;
        }
        #ff-btn-submit-map:hover { background: #d97706; }
        
        #ff-stop-mapping-btn {
            position: fixed; top: 20px; right: 20px; z-index: 2147483647;
            width: auto !important; min-width: 140px; padding: 10px 20px;
            background: #ef4444; color: white; border: none; border-radius: 50px;
            font-weight: bold; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            display: flex; align-items: center; justify-content: center; gap: 8px;
            font-family: system-ui, sans-serif; transition: transform 0.2s;
        }
        #ff-stop-mapping-btn:hover { transform: scale(1.05); background: #dc2626; }
    `;
    document.head.appendChild(style);
};

var createFloatingPanel = () => {
    if (document.getElementById('ff-floating-panel')) return;
    var panel = document.createElement('div');
    panel.id = 'ff-floating-panel';
    panel.innerHTML = `
        <p id="ff-field-name" style="font-weight:bold; color:#1e293b;">Field Name</p>
        <select id="ff-column-select" style="margin-bottom:10px;"></select>
        
        <label style="display:flex; align-items:center; gap:8px; font-size:11px; color:#64748b; margin-bottom:12px; cursor:pointer;">
            <input type="checkbox" id="ff-wait-toggle"> 
            Wait for Server/Mutation (Async)
        </label>

        <div class="ff-btns">
            <button id="ff-btn-cancel">Cancel</button>
            <button id="ff-btn-save">Map Data</button>
        </div>
        <button id="ff-btn-submit-map">🎯 Map as Submit Button</button>
    `;
    document.body.appendChild(panel);
    document.getElementById('ff-btn-cancel').onclick = closePanel;
    document.getElementById('ff-btn-save').onclick = saveMapping;
    document.getElementById('ff-btn-submit-map').onclick = saveSubmitMapping;
};

// ==========================================
// 3. SMART HELPERS (Selectors & Labels)
// ==========================================
var getBestSelector = (el) => {
    if (el.name) return `${el.tagName.toLowerCase()}[name="${el.name}"]`;
    if (el.id) return `#${CSS.escape(el.id)}`;
    
    // Explicit Button Handling
    if (el.tagName === 'BUTTON' && el.type === 'submit') return 'button[type="submit"]';
    if (el.tagName === 'INPUT' && el.type === 'submit') return 'input[type="submit"]';

    if (el.className && typeof el.className === 'string') {
        const classes = el.className.split(' ')
            .filter(c => !c.startsWith('ff-') && !c.includes('focus') && !c.includes('hover') && !c.includes('active'))
            .join('.');
        if (classes) return `${el.tagName.toLowerCase()}.${classes}`;
    }
    return el.tagName.toLowerCase();
};

var findLabel = (el) => {
    if (el.tagName === 'BUTTON') {
        return (el.innerText || el.textContent || "Submit Button").trim();
    }
    if (el.tagName === 'INPUT' && (el.type === 'submit' || el.type === 'button')) {
        return (el.value || "Submit Button").trim();
    }

    if (el.id) {
        try {
            const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
            if (label && label.innerText.trim()) return label.innerText.trim();
        } catch (e) {}
    }
    const parentLabel = el.closest('label');
    // FIX: previously this did `.replace(el.value || '', '')`, which blanked the
    // label out completely whenever value === visible text (e.g. value="Male", text="Male").
    if (parentLabel && parentLabel.innerText.trim()) return parentLabel.innerText.trim();

    if (el.previousElementSibling && el.previousElementSibling.tagName === 'LABEL') {
        if (el.previousElementSibling.innerText.trim()) return el.previousElementSibling.innerText.trim();
    }
    if (el.parentElement) {
        const containerLabel = el.parentElement.querySelector('label');
        if (containerLabel && containerLabel.innerText.trim()) return containerLabel.innerText.trim();
    }
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) return ariaLabel;
    if (el.placeholder) return el.placeholder;

    let fallback = el.name || el.id || "Unnamed Field";
    fallback = fallback.replace(/[-_]/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim();
    fallback = fallback.replace(/\b\w/g, l => l.toUpperCase()); 
    return fallback;
};

// ==========================================
// 4. EVENT HANDLERS (The Visual Picker)
// ==========================================
var isExtensionUI = (el) => {
    if (!el || !el.closest) return false;
    return el.closest('#ff-floating-panel') || el.closest('#ff-stop-mapping-btn') || el.closest('#ff-player') || el.closest('#ff-auto-panel');
};

// NEW: many radio/checkbox groups only visually respond to clicks on the
// wrapping <label>, not the input itself. Resolve the label back to its
// real form control so mapping/hovering works on those layouts too.
var resolveMappableTarget = (el) => {
    if (!el) return el;
    if (el.tagName === 'LABEL') {
        var forId = el.getAttribute('for');
        var associated = forId ? document.getElementById(forId) : el.querySelector('input, select, textarea, button');
        if (associated) return associated;
    }
    return el;
};

var handleMouseOver = (e) => {
    if (!isMappingMode || isPanelOpen) return;
    var el = resolveMappableTarget(e.target);
    if (isExtensionUI(el)) return; 
    
    if (['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(el.tagName)) {
        hoveredElement = el;
        el.classList.add('ff-highlight');
    }
};

var handleMouseOut = () => {
    if (isPanelOpen) return;
    if (hoveredElement) hoveredElement.classList.remove('ff-highlight');
    hoveredElement = null;
};

var handleMouseDown = (e) => {
    if (!isMappingMode) return;
    if (isExtensionUI(e.target)) return; 
    if (e.target.tagName === 'SELECT') e.preventDefault();
};

var handleClick = (e) => {
    if (!isMappingMode) return;
    var el = resolveMappableTarget(e.target);
    if (isExtensionUI(el)) return; 
    
    if (isPanelOpen) {
        closePanel();
        return;
    }

    if (['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(el.tagName)) {
        e.preventDefault(); 
        e.stopPropagation();
        
        isPanelOpen = true;
        hoveredElement = el;
        hoveredElement.classList.add('ff-highlight');

        targetSelector = getBestSelector(el);
        targetLabel = findLabel(el);
        if (targetLabel === "Unnamed Field" && (el.innerText || el.value)) {
            targetLabel = (el.innerText || el.value).trim();
        }

        document.getElementById('ff-field-name').innerText = `Target: ${targetLabel}`;
        var toggle = document.getElementById('ff-wait-toggle');
        if (toggle) toggle.checked = false;
        
        var select = document.getElementById('ff-column-select');
        select.innerHTML = '<option value="">-- Choose CSV Column --</option>' + 
            currentHeaders.map(h => `<option value="${h}">${h}</option>`).join('');
        
        var panel = document.getElementById('ff-floating-panel');
        panel.style.display = 'block';
        
        var rect = el.getBoundingClientRect();
        panel.style.top = `${window.scrollY + rect.bottom + 8}px`;
        panel.style.left = `${window.scrollX + rect.left}px`;
    }
   
};

// ==========================================
// 5. STATE MANAGEMENT
// ==========================================
var closePanel = () => {
    const panel = document.getElementById('ff-floating-panel');
    if (panel) panel.style.display = 'none';
    isPanelOpen = false;
    if (hoveredElement) {
        hoveredElement.classList.remove('ff-highlight');
        hoveredElement = null;
    }
};

var saveMapping = () => {
    var column = document.getElementById('ff-column-select').value;
    var wait = document.getElementById('ff-wait-toggle').checked;
    if (!column) return alert("Select a column");
    
    var cleanPath = window.location.pathname;
    if (cleanPath.length > 1 && cleanPath.endsWith('/')) cleanPath = cleanPath.slice(0, -1);
    var storageKey = `ff_map_${window.location.hostname}${cleanPath}`;
    
    chrome.storage.sync.get([storageKey], (result) => {
        var mappings = result[storageKey] || [];
        var newMap = { column, selector: targetSelector, label: targetLabel, wait: wait };
        
        var idx = mappings.findIndex(m => m.column === column);
        if (idx > -1) mappings[idx] = newMap; 
        else mappings.push(newMap);
        
        chrome.storage.sync.set({ [storageKey]: mappings }, () => {
            closePanel();
            chrome.runtime.sendMessage({ action: "MAPPINGS_UPDATED" });
        });
    });
};

var saveSubmitMapping = () => {
    var cleanPath = window.location.pathname;
    if (cleanPath.length > 1 && cleanPath.endsWith('/')) cleanPath = cleanPath.slice(0, -1);
    var storageKey = `ff_map_${window.location.hostname}${cleanPath}`;
    
    chrome.storage.sync.get([storageKey], (result) => {
        var mappings = result[storageKey] || [];
        
        var newMap = { 
            column: 'FF_SUBMIT_BTN', 
            selector: targetSelector, 
            label: targetLabel,
            wait: false 
        };
        
        var idx = mappings.findIndex(m => m.column === 'FF_SUBMIT_BTN');
        if (idx > -1) mappings[idx] = newMap; 
        else mappings.push(newMap);
        
        chrome.storage.sync.set({ [storageKey]: mappings }, () => {
            var btn = document.getElementById('ff-btn-submit-map');
            btn.innerText = "✓ Mapped!";
            btn.style.background = "#10b981"; 
            setTimeout(() => {
                btn.innerText = "🎯 Map as Submit Button";
                btn.style.background = "#f59e0b"; 
                closePanel();
                chrome.runtime.sendMessage({ action: "MAPPINGS_UPDATED" });
            }, 600);
        });
    });
};

var toggleMappingMode = (active) => {
    isMappingMode = active;
    if (active) {
        isPanelOpen = false;
        injectStyles();
        createFloatingPanel();
        
        document.querySelectorAll('input:disabled, select:disabled, textarea:disabled, button:disabled').forEach(el => {
            el.dataset.ffWasDisabled = 'true';
            el.disabled = false;
            el.style.borderStyle = 'dashed';
        });
        
        if (!document.getElementById('ff-stop-mapping-btn')) {
            var stopBtn = document.createElement('button');
            stopBtn.id = 'ff-stop-mapping-btn';
            stopBtn.innerHTML = '<span>✕</span> Stop Mapping';
            stopBtn.onclick = () => toggleMappingMode(false);
            document.body.appendChild(stopBtn);
        }

        document.addEventListener('mouseover', handleMouseOver);
        document.addEventListener('mouseout', handleMouseOut);
        document.addEventListener('mousedown', handleMouseDown, true);
        document.addEventListener('click', handleClick, true);
    } else {
        var stopBtn = document.getElementById('ff-stop-mapping-btn');
        if (stopBtn) stopBtn.remove();
        closePanel();
        
        document.querySelectorAll('[data-ff-was-disabled="true"]').forEach(el => {
            el.disabled = true;
            el.style.borderStyle = '';
            delete el.dataset.ffWasDisabled;
        });
        
        document.removeEventListener('mouseover', handleMouseOver);
        document.removeEventListener('mouseout', handleMouseOut);
        document.removeEventListener('mousedown', handleMouseDown, true);
        document.removeEventListener('click', handleClick, true);
    }
};

// ==========================================
// 6. AUTO-FILL ENGINE (User-Defined Hybrid Engine)
// ==========================================

// NEW: React/Vue/Angular register their own setters on value/checked to
// track state internally. Setting `.value = x` directly gets silently
// ignored by those frameworks. Calling the *native* prototype setter first,
// then dispatching the event, makes frameworks pick up the change reliably.
var setNativeValue = (element, value) => {
    var proto = Object.getPrototypeOf(element);
    var descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) {
        descriptor.set.call(element, value);
    } else {
        element.value = value;
    }
};

var setNativeChecked = (element, checked) => {
    var proto = Object.getPrototypeOf(element);
    var descriptor = Object.getOwnPropertyDescriptor(proto, 'checked');
    if (descriptor && descriptor.set) {
        descriptor.set.call(element, checked);
    } else {
        element.checked = checked;
    }
};

var TRUTHY_VALUES = ['true', 'yes', '1', 'on', 'checked', 'y'];

var fillForm = async (rowData, mappings) => {
    for (let map of mappings) {
        if (map.column === 'FF_SUBMIT_BTN') continue;

        var element = document.querySelector(map.selector);
        var value = rowData[map.column];

        // Skip blank cells entirely so re-filling a row never wipes out an
        // already-checked radio/checkbox or a previously selected option.
        if (!element || value === undefined || value === null || String(value).trim() === '') {
            continue;
        }

        // ---------- SELECT / DROPDOWN ----------
        if (element.tagName === 'SELECT') {
            var strValue = String(value).trim();
            var strValueLower = strValue.toLowerCase();
            var options = Array.from(element.options);

            if (element.multiple) {
                var targetList = strValue.split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
                options.forEach(opt => {
                    var optVal = opt.value.trim().toLowerCase();
                    var optText = opt.text.trim().toLowerCase();
                    opt.selected = targetList.includes(optVal) || targetList.includes(optText);
                });
            } else {
                // Try exact value match first, then case-insensitive value,
                // then case-insensitive visible text (handles CSVs that use
                // display labels like "United States" instead of "US").
                var match = options.find(opt => opt.value === strValue) ||
                            options.find(opt => opt.value.trim().toLowerCase() === strValueLower) ||
                            options.find(opt => opt.text.trim().toLowerCase() === strValueLower);
                setNativeValue(element, match ? match.value : strValue);
            }

            element.dispatchEvent(new Event('input', { bubbles: true }));
            element.dispatchEvent(new Event('change', { bubbles: true }));

            element.style.backgroundColor = '#dcfce7';
            setTimeout(() => { element.style.backgroundColor = ''; }, 500);
            continue;
        }

        // ---------- RADIO / CHECKBOX ----------
        if (element.type === 'radio' || element.type === 'checkbox') {
            // For radio groups (and multi-checkbox groups sharing a `name`),
            // map.selector resolves to ALL members of the group, so grab them
            // all and pick the one(s) whose value/label match the CSV cell.
            var groupElements = Array.from(document.querySelectorAll(map.selector))
                .filter(el2 => el2.type === element.type);

            var isGroup = element.type === 'radio' || groupElements.length > 1;

            if (isGroup) {
                var targetList = String(value).split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
                groupElements.forEach(input => {
                    var inputValueLower = (input.value || '').trim().toLowerCase();
                    var inputLabelLower = findLabel(input).trim().toLowerCase();
                    var shouldCheck = targetList.includes(inputValueLower) || targetList.includes(inputLabelLower);

                    if (input.checked !== shouldCheck) {
                        setNativeChecked(input, shouldCheck);
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                        input.dispatchEvent(new Event('click', { bubbles: true }));
                    }
                });
            } else {
                // Standalone boolean checkbox (e.g. "Subscribe to newsletter")
                var truthy = TRUTHY_VALUES.includes(String(value).trim().toLowerCase());
                if (element.checked !== truthy) {
                    setNativeChecked(element, truthy);
                    element.dispatchEvent(new Event('input', { bubbles: true }));
                    element.dispatchEvent(new Event('change', { bubbles: true }));
                    element.dispatchEvent(new Event('click', { bubbles: true }));
                }
            }

            groupElements.forEach(input => {
                input.style.backgroundColor = '#dcfce7';
                setTimeout(() => { input.style.backgroundColor = ''; }, 500);
            });
            continue;
        }

        // ---------- TEXT / TEXTAREA / COMBOBOX ----------
        element.focus();
        setNativeValue(element, value);
        element.dispatchEvent(new Event('input', { bubbles: true }));

        if (map.wait) {
            // SNIPER MODE: only runs if "Wait for Server/Mutation" was checked
            await new Promise((resolve) => {
                var dropObserver = new MutationObserver((mutations) => {
                    var listAppeared = mutations.some(m => m.addedNodes.length > 0);
                    if (listAppeared) {
                        var targetString = String(value).toLowerCase().trim();
                        var match = Array.from(document.querySelectorAll('li, [role="option"], .item'))
                            .find(el => (el.innerText || '').toLowerCase().trim() === targetString);

                        if (match) {
                            dropObserver.disconnect();
                            clearTimeout(failsafe);
                            setTimeout(() => {
                                match.dispatchEvent(new MouseEvent('click', { bubbles: true }));
                                element.dispatchEvent(new Event('change', { bubbles: true }));
                                resolve();
                            }, 50);
                        }
                    }
                });
                dropObserver.observe(document.body, { childList: true, subtree: true });
                var failsafe = setTimeout(() => { dropObserver.disconnect(); resolve(); }, 10000);
            });
        } else {
            element.dispatchEvent(new Event('change', { bubbles: true }));
        }

        element.style.backgroundColor = '#dcfce7';
        setTimeout(() => { element.style.backgroundColor = ''; }, 500);
    }
};

// ==========================================
// 8. THE PERSISTENT FLOATING PLAYER (Pro UI)
// ==========================================
var createPlayer = (data, initialRowIndex, mappings) => {
    if (document.getElementById('ff-player')) return;

    var currentRowIndex = initialRowIndex || 0;

    var style = document.createElement('style');
    style.id = 'ff-manual-styles';
    style.innerHTML = `
        #ff-player {
            position: fixed; bottom: 24px; right: 24px; z-index: 2147483647;
            background: white; border: 1px solid #e2e8f0; border-radius: 16px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1);
            padding: 20px; width: 300px; font-family: system-ui, -apple-system, sans-serif;
            display: flex; flex-direction: column; gap: 14px;
            border-top: 4px solid #8b5cf6; 
        }
        .ff-player-header { display: flex; justify-content: space-between; align-items: center; }
        .ff-player-brand { display: flex; align-items: center; gap: 6px; font-weight: 800; color: #8b5cf6; font-size: 12px; letter-spacing: 0.5px; }
        
        .ff-player-close { 
            cursor: pointer; color: #94a3b8; border: 1px solid #e2e8f0; 
            background: #f8fafc; border-radius: 50%; width: 28px; height: 28px;       
            display: flex; align-items: center; justify-content: center;
            font-size: 14px; font-weight: bold; line-height: 1; padding: 0; transition: all 0.2s;
        }
        .ff-player-close:hover { color: #ef4444; background: #fee2e2; border-color: #fca5a5; transform: rotate(90deg); }

        .ff-progress-container { margin-top: 4px; }
        .ff-progress-stats { display: flex; justify-content: space-between; font-size: 11px; font-weight: 700; color: #64748b; margin-bottom: 6px; text-transform: uppercase; }
        .ff-progress-bar { width: 100%; height: 6px; background: #f1f5f9; border-radius: 3px; overflow: hidden; }
        #ff-bar-fill { height: 100%; background: #8b5cf6; transition: width 0.4s cubic-bezier(0.4, 0, 0.2, 1); width: 0%; }

        .ff-row-info { text-align: center; margin: 8px 0; }
        .ff-row-number { font-size: 28px; font-weight: 900; color: #1e293b; display: block; line-height: 1; }
        .ff-row-label { font-size: 12px; color: #94a3b8; font-weight: 500; }

        .ff-player-controls { display: flex; gap: 10px; }
        .ff-nav-btn { 
            flex: 1; padding: 12px; border: none; border-radius: 10px; 
            font-weight: 700; cursor: pointer; transition: all 0.2s; 
            background: #f8fafc; color: #475569; border: 1px solid #e2e8f0;
            display: flex; flex-direction: column; align-items: center; gap: 4px; font-size: 11px;
        }
        .ff-nav-btn:hover:not(:disabled) { background: #f1f5f9; border-color: #cbd5e1; color: #1e293b; }
        .ff-nav-btn:active:not(:disabled) { transform: scale(0.95); }
        .ff-nav-btn:disabled { opacity: 0.4; cursor: not-allowed; }
        
        .ff-nav-btn.primary { background: #8b5cf6; color: white; border: none; box-shadow: 0 4px 6px -1px rgba(139, 92, 246, 0.3); }
        .ff-nav-btn.primary:hover { background: #7c3aed; color: white; }
        .ff-icon-small { font-size: 16px; }
    `;
    document.head.appendChild(style);

    var player = document.createElement('div');
    player.id = 'ff-player';
    player.innerHTML = `
        <div class="ff-player-header">
            <div class="ff-player-brand">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
                FORMFLOW
            </div>
            <button id="ff-player-close" class="ff-player-close" title="Exit">✕</button>
        </div>
        <div class="ff-progress-container">
            <div class="ff-progress-stats"><span>Progress</span><span id="ff-progress-text">0%</span></div>
            <div class="ff-progress-bar"><div id="ff-bar-fill"></div></div>
        </div>
        <div class="ff-row-info">
            <span id="ff-row-val" class="ff-row-number">1</span>
            <span class="ff-row-label">of ${data.length} records</span>
        </div>
        <div class="ff-player-controls">
            <button id="ff-btn-prev" class="ff-nav-btn"><span class="ff-icon-small">←</span>PREV</button>
            <button id="ff-btn-fill" class="ff-nav-btn primary"><span class="ff-icon-small">⚡</span>RE-FILL</button>
            <button id="ff-btn-next" class="ff-nav-btn"><span class="ff-icon-small">→</span>NEXT</button>
        </div>
    `;
    document.body.appendChild(player);

    var updateUI = () => {
        var progress = Math.round(((currentRowIndex + 1) / data.length) * 100);
        document.getElementById('ff-row-val').innerText = currentRowIndex + 1;
        document.getElementById('ff-progress-text').innerText = progress + "%";
        document.getElementById('ff-bar-fill').style.width = progress + "%";
        
        document.getElementById('ff-btn-prev').disabled = currentRowIndex === 0;
        document.getElementById('ff-btn-next').disabled = currentRowIndex >= data.length - 1;
    };

    document.getElementById('ff-player-close').onclick = () => {
        chrome.storage.local.set({ ff_session_active: false }, () => player.remove());
    };

    document.getElementById('ff-btn-prev').onclick = async () => {
        if (currentRowIndex > 0) {
            currentRowIndex--;
            updateUI();
            chrome.storage.local.set({ savedRowIndex: currentRowIndex });
            await fillForm(data[currentRowIndex], mappings);
        }
    };

    document.getElementById('ff-btn-next').onclick = async () => {
        if (currentRowIndex < data.length - 1) {
            currentRowIndex++;
            updateUI();
            chrome.storage.local.set({ savedRowIndex: currentRowIndex });
            await fillForm(data[currentRowIndex], mappings);
        }
    };

    document.getElementById('ff-btn-fill').onclick = async () => {
        await fillForm(data[currentRowIndex], mappings);
        var btn = document.getElementById('ff-btn-fill');
        btn.style.background = "#10b981";
        setTimeout(() => btn.style.background = "#8b5cf6", 300);
    };

    updateUI();
    fillForm(data[currentRowIndex], mappings); 
};

// ==========================================
// 8.6 THE AUTOMATED RUNNER (Auto-Pilot & AJAX)
// ==========================================
var createAutoBanner = async (data, rowIndex, mappings, delaySec) => {
    if (document.getElementById('ff-auto-panel')) return;
    if (rowIndex === 0 && typeof FF_AuditLogger !== 'undefined') {
        FF_AuditLogger.startSession();
    }
    var progressPercent = Math.round(((rowIndex) / data.length) * 100);

    var style = document.createElement('style');
    style.id = 'ff-auto-styles';
    style.innerHTML = `
        #ff-auto-panel {
            position: fixed; bottom: 20px; right: 20px; z-index: 2147483647;
            background: white; border: 2px solid #10b981; border-radius: 12px;
            box-shadow: 0 15px 30px -5px rgba(0,0,0,0.2), 0 0 15px rgba(16, 185, 129, 0.2); 
            width: 280px; padding: 16px; font-family: system-ui, sans-serif;
            display: flex; flex-direction: column; gap: 12px;
        }
        .ff-auto-header { display: flex; justify-content: space-between; align-items: center; }
        .ff-auto-title { font-weight: 800; color: #10b981; font-size: 13px; display: flex; align-items: center; gap: 8px; }
        .ff-pulse { width: 10px; height: 10px; background: #10b981; border-radius: 50%; animation: ff-ping 1.5s infinite; }
        @keyframes ff-ping { to { box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); } }
        .ff-row-badge { background: #f1f5f9; color: #475569; padding: 4px 8px; border-radius: 6px; font-size: 11px; font-weight: bold; }
        .ff-progress-bg { width: 100%; height: 6px; background: #e2e8f0; border-radius: 3px; overflow: hidden; }
        .ff-progress-fill { height: 100%; background: #10b981; transition: width 0.3s ease; width: ${progressPercent}%; }
        .ff-auto-status { text-align: center; font-size: 16px; font-weight: 900; color: #1e293b; margin: 2px 0; }
        .ff-auto-log { font-size: 11px; color: #64748b; text-align: center; font-style: italic; min-height: 16px; }
        #ff-auto-stop { background: #ef4444; color: white; border: none; padding: 10px; border-radius: 6px; font-weight: bold; cursor: pointer; transition: all 0.2s; }
        #ff-auto-stop:active { transform: scale(0.96); }
        #ff-auto-stop:hover { background: #dc2626; }
    `;
    document.head.appendChild(style);

    var panel = document.createElement('div');
    panel.id = 'ff-auto-panel';
    panel.innerHTML = `
        <div class="ff-auto-header">
            <div class="ff-auto-title"><div class="ff-pulse"></div> AUTO-PILOT</div>
            <div class="ff-row-badge">Row ${rowIndex + 1} / ${data.length}</div>
        </div>
        <div class="ff-progress-bg"><div class="ff-progress-fill"></div></div>
        <div id="ff-countdown" class="ff-auto-status">Submitting in ${delaySec.toFixed(1)}s</div>
        <div id="ff-sys-log" class="ff-auto-log">Filling form data...</div>
        <button id="ff-auto-stop">🛑 Stop Auto Mode</button>
    `;
    document.body.appendChild(panel);

    var logStatus = (msg) => { document.getElementById('ff-sys-log').innerText = msg; };

    var timerInterval, submitTimeout, domObserver;
    var stopAutoMode = (isManualStop = false) => {
        clearInterval(timerInterval);
        clearTimeout(submitTimeout);
        if (domObserver) domObserver.disconnect();
        
        chrome.storage.local.set({ ff_session_active: false, ff_auto_mode: false }, () => {
            if (panel) panel.remove();
            
            if (isManualStop && typeof FF_AuditLogger !== 'undefined') {
                FF_AuditLogger.logRow(rowIndex, "ABORTED", "User manually stopped.");
                setTimeout(() => {
                    if(confirm("Automation Stopped! Download partial Audit Report?")){
                        FF_AuditLogger.downloadReport();
                    }
                }, 100);
            }
        });
    };

    document.getElementById('ff-auto-stop').onclick = () => stopAutoMode(true);

    await fillForm(data[rowIndex], mappings);

    if (typeof FF_AuditLogger !== 'undefined') FF_AuditLogger.logRow(rowIndex, "SUCCESS");

    var timeLeft = delaySec;
    var countdownEl = document.getElementById('ff-countdown');
    
    timerInterval = setInterval(() => {
        timeLeft -= 0.1;
        countdownEl.innerText = `Submitting in ${Math.max(0, timeLeft).toFixed(1)}s`;
        
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            countdownEl.innerText = "Submitting...";
            logStatus("Locating submit button...");
            
            var nextIndex = rowIndex + 1;
            chrome.storage.local.get(['ff_auto_stop_index'], (res) => {
                var isComplete = nextIndex >= data.length || (res.ff_auto_stop_index && nextIndex >= res.ff_auto_stop_index);
                
                chrome.storage.local.set({ savedRowIndex: isComplete ? rowIndex : nextIndex }, () => {
                    if (isComplete) {
                        stopAutoMode();
                        logStatus("Task Complete!");
                        
                        setTimeout(() => {
                            if(confirm("Automation Complete! Download Audit Report?")){
                                if (typeof FF_AuditLogger !== 'undefined') FF_AuditLogger.downloadReport();
                            }
                        }, 100);
                        return;
                    }

                    var submitMap = mappings.find(m => m.column === 'FF_SUBMIT_BTN');
                  
                    if (!submitMap) {
                        stopAutoMode(true);
                        return alert("Error: You must map a Submit Button first!");
                    }
                    
                    var submitBtn = document.querySelector(submitMap.selector);

                    if (submitBtn) {
                        submitBtn.style.boxShadow = "0 0 0 4px #ef4444"; 
                        logStatus("Clicking submit...");
                        
                        domObserver = new MutationObserver((mutations) => {
                            domObserver.disconnect();
                            clearTimeout(submitTimeout);
                            logStatus("AJAX Success Detected. Loading next row...");
                            setTimeout(() => {
                                panel.remove();
                                createAutoBanner(data, nextIndex, mappings, delaySec);
                            }, 800); 
                        });
                        domObserver.observe(document.body, { childList: true, subtree: true });
                        setTimeout(() => submitBtn.click(), 200);
                        
                        submitTimeout = setTimeout(() => {
                            if (domObserver) domObserver.disconnect();
                            logStatus("Timeout reached. Forcing next row...");
                            panel.remove();
                            createAutoBanner(data, nextIndex, mappings, delaySec);
                        }, delaySec * 1000);
                        
                        window.addEventListener('beforeunload', () => clearTimeout(submitTimeout));

                    } else {
                        stopAutoMode(true);
                        alert("ERROR: Could not find the mapped Submit button on the screen.");
                    }
                });
            });
        }
    }, 100);
};

// ==========================================
// 9. THE AUTO-BOOT LOADER
// ==========================================
chrome.storage.local.get(['ff_session_active', 'ff_auto_mode', 'activeTable', 'savedRowIndex', 'ff_auto_delay'], (res) => {
    if (res.ff_session_active && res.activeTable) {
        var cleanPath = window.location.pathname;
        if (cleanPath.length > 1 && cleanPath.endsWith('/')) cleanPath = cleanPath.slice(0, -1);
        var storageKey = `ff_map_${window.location.hostname}${cleanPath}`;
        
        chrome.storage.sync.get([storageKey], (syncRes) => {
            var mappings = syncRes[storageKey];
            if (mappings && mappings.length > 0) {
                var rIndex = res.savedRowIndex || 0;
                if (res.ff_auto_mode) {
                    var delay = res.ff_auto_delay || 2.0;
                    createAutoBanner(res.activeTable, rIndex, mappings, delay);
                } else {
                    createPlayer(res.activeTable, rIndex, mappings);
                }
            }
        });
    }
});

// ==========================================
// 10. MESSAGE LISTENER
// ==========================================
var ffMessageListener = (request, sender, sendResponse) => {
    if (request.action === "START_MAPPING") {
        currentHeaders = request.headers;
        toggleMappingMode(true);
        sendResponse({status: "Mapping Started"}); 
    }
    if (request.action === "START_PLAYER") {
        createPlayer(request.data, request.rowIndex, request.mappings);
        sendResponse({status: "Manual Player Started"});
    }
    if (request.action === "START_AUTO_PLAYER") {
        createAutoBanner(request.data, request.rowIndex, request.mappings, request.delay);
        sendResponse({status: "Auto Player Started"});
    }
};

chrome.runtime.onMessage.removeListener(ffMessageListener);
chrome.runtime.onMessage.addListener(ffMessageListener);
