// popup/popup.js

document.addEventListener('DOMContentLoaded', () => {

  // ==========================================
  // 1. TAB NAVIGATION LOGIC
  // ==========================================
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => {
        b.classList.remove('text-violet-600', 'border-b-2', 'border-violet-600');
        b.classList.add('text-slate-500');
      });
      tabContents.forEach(content => {
        content.classList.remove('active');
        content.classList.add('hidden');
      });

      btn.classList.add('text-violet-600', 'border-b-2', 'border-violet-600');
      btn.classList.remove('text-slate-500');
      const targetId = btn.getAttribute('data-target');
      const targetContent = document.getElementById(targetId);
      targetContent.classList.remove('hidden');
      targetContent.classList.add('active');
    });
  });

  // ==========================================
  // 2. UPLOAD & DRAG-AND-DROP LOGIC
  // ==========================================
  const fileInput = document.getElementById('fileInput');
  const dropZone = document.getElementById('dropZone');
  const previewArea = document.getElementById('previewArea');
  const loadingIndicator = document.getElementById('loadingIndicator');
  
  let currentData = null; 
  let currentHeaders = [];

  dropZone.addEventListener('click', () => {
    const isFirefox = navigator.userAgent.toLowerCase().includes('firefox');
    
    // Check the URL to see if we are already in the standalone window
    const urlParams = new URLSearchParams(window.location.search);
    const isStandaloneWindow = urlParams.get('mode') === 'window';
    
    // If it's Firefox AND we are in the standard toolbar popup
    if (isFirefox && !isStandaloneWindow) {
      
      // Open the new window and append '?mode=window' to the URL
      chrome.windows.create({
        url: chrome.runtime.getURL("popup/index.html?mode=window"),
        type: "popup",      
        width: 400,         
        height: 620,        
        focused: true
      });
      window.close(); // Close the buggy toolbar popup
      
    } else {
      // Normal behavior: We are either in Chrome/Edge, OR we are already 
      // in the standalone Firefox window where it is safe to open the dialog.
      document.getElementById('fileInput').click();
    }
  });

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('bg-slate-100', 'border-violet-400');
  });
  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('bg-slate-100', 'border-violet-400');
  });
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('bg-slate-100', 'border-violet-400');
    if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) handleFile(e.target.files[0]);
  });

  async function handleFile(file) {
    if (!file) return;
    
    const hasHeaders = document.getElementById('hasHeadersCheck').checked;
    const ext = file.name.split('.').pop().toLowerCase();
    
    dropZone.classList.add('hidden');
    loadingIndicator.classList.remove('hidden');
    loadingIndicator.classList.add('flex');

    const reader = new FileReader();

    reader.onload = async function(event) {
      try {
        let parsed;
        if (ext === 'csv') {
          parsed = DataParser.parseCSV(event.target.result, hasHeaders);
        } else if (ext === 'xlsx' || ext === 'xls') {
          parsed = await DataParser.parseExcel(event.target.result, hasHeaders);
        } else if (ext === 'docx') {
          parsed = await DataParser.parseWord(event.target.result, hasHeaders);
        } else {
          throw new Error("Unsupported file type.");
        }

        currentData = parsed.data;
        currentHeaders = parsed.headers;
        
        chrome.storage.local.set({ 
          activeTable: currentData, 
          activeHeaders: currentHeaders,
          fileName: file.name 
        });

        renderPreviewTable(file.name, currentHeaders, currentData);
        
      } catch (err) {
        alert("Error parsing file: " + err.message);
        resetUploadUI();
      }
    };

    if (ext === 'csv') reader.readAsText(file);
    else reader.readAsArrayBuffer(file);
  }

  function renderPreviewTable(fileName, headers, data) {
    loadingIndicator.classList.add('hidden');
    loadingIndicator.classList.remove('flex');
    previewArea.classList.remove('hidden');
    previewArea.classList.add('flex');

    document.getElementById('fileName').textContent = fileName;
    document.getElementById('fileStats').textContent = `${data.length} rows • ${headers.length} columns`;

    const thead = document.getElementById('previewThead');
    const tbody = document.getElementById('previewTbody');
    
    thead.innerHTML = '<tr>' + headers.map(h => `<th class="p-2 font-medium">${h}</th>`).join('') + '</tr>';
    
    const previewData = data.slice(0, 15);
    tbody.innerHTML = previewData.map(row => {
      return '<tr>' + headers.map(h => `<td class="p-2 truncate max-w-[120px]" title="${row[h]}">${row[h] || ''}</td>`).join('') + '</tr>';
    }).join('');
  }

  function resetUploadUI() {
    fileInput.value = '';
    currentData = null;
    currentHeaders = [];
    previewArea.classList.add('hidden');
    previewArea.classList.remove('flex');
    dropZone.classList.remove('hidden');
    chrome.storage.local.remove(['activeTable', 'activeHeaders', 'fileName']);
  }

  document.getElementById('clearTableBtn').addEventListener('click', resetUploadUI);
  
  document.getElementById('useTableBtn').addEventListener('click', () => {
    document.querySelector('[data-target="mapping"]').click();
  });


  // ==========================================
  // 3. MAPPING, TEMPLATES & STORAGE LOGIC
  // ==========================================
  const mappingList = document.getElementById('mappingList');
  let currentMappings = []; 
  let currentHostname = '';
  let storageKey = '';

   function syncHeadersWithMappings() {
    currentMappings.forEach(mapObj => {
      // Ignore the submit button, add everything else to the headers list
      if (mapObj.column && mapObj.column !== 'FF_SUBMIT_BTN' && !currentHeaders.includes(mapObj.column)) {
        currentHeaders.push(mapObj.column);
      }
    });
  }

  // Get current tab hostname + path on load
  async function initSiteContext() {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    if (tab && tab.url && !tab.url.startsWith('chrome://')) {
      const urlObj = new URL(tab.url);
      currentHostname = urlObj.hostname;
      // Combine Hostname AND Pathname for multi-step forms
      let cleanPath = urlObj.pathname;
      if (cleanPath.length > 1 && cleanPath.endsWith('/')) cleanPath = cleanPath.slice(0, -1);
      storageKey = `ff_map_${urlObj.hostname}${cleanPath}`;
      loadSiteMappings();
    }
  }

  function loadSiteMappings() {
    chrome.storage.sync.get([storageKey], (result) => {
      currentMappings = result[storageKey] || [];
      syncHeadersWithMappings();
      renderMappings();
    });
  }

  // Visual Picker trigger
  document.getElementById('startMappingBtn').addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    const startMessage = { action: "START_MAPPING", headers: currentHeaders };
    
    chrome.tabs.sendMessage(tab.id, startMessage, () => {
      if (chrome.runtime.lastError) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content/content.js"]
        }).then(() => {
          setTimeout(() => {
            chrome.tabs.sendMessage(tab.id, startMessage);
            window.close(); // Close popup automatically
          }, 100);
        }).catch(err => alert("Cannot map this specific page."));
      } else {
        window.close(); // Close popup automatically
      }
    });
  });

  chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "MAPPINGS_UPDATED") {
      loadSiteMappings(); 
    }
  });

function renderMappings() {
    document.getElementById('mappingCount').textContent = currentMappings.length;
    
    if (currentMappings.length === 0) {
      mappingList.innerHTML = '<p class="text-xs text-center text-slate-400 italic mt-4">No fields mapped yet.</p>';
      document.getElementById('showSaveTemplateBtn').classList.add('hidden');
      return;
    }

    mappingList.innerHTML = ''; 
    currentMappings.forEach((mapObj, index) => {
      // Only show the badge if it's NOT the submit button and wait is true
const isSubmit = mapObj.column === 'FF_SUBMIT_BTN';
const asyncBadge = (!isSubmit && mapObj.wait) ? `<span style="font-size:9px; background:#ede9fe; color:#7c3aed; padding:1px 4px; border-radius:4px; margin-left:4px; font-weight:bold;">ASYNC</span>` : '';
      const row = document.createElement('div');
      row.className = "flex items-center justify-between bg-white p-3 rounded-lg border border-slate-200 shadow-sm text-sm hover:border-violet-300 transition-colors";
      
      // Check if this field was saved with the 'wait' toggle enabled
      

      row.innerHTML = `
        <div class="flex flex-col w-[45%] overflow-hidden">
          <span class="text-[10px] uppercase tracking-wider text-slate-400 font-bold mb-1">CSV Column</span>
          <span class="font-bold text-violet-700 truncate" title="${mapObj.column}">${mapObj.column}</span>
        </div>
        
        <div class="text-slate-300 px-1">→</div>
        
        <div class="flex flex-col w-[45%] overflow-hidden text-right">
          <span class="text-[10px] uppercase tracking-wider text-slate-400 font-bold mb-1">Web Field ${asyncBadge}</span>
          <span class="font-bold text-slate-700 truncate" title="${mapObj.label}">${mapObj.label}</span>
          <span class="text-[9px] text-slate-300 font-mono truncate">${mapObj.selector}</span>
        </div>
        
        <button class="ml-3 text-slate-300 hover:text-red-500 delete-map-btn transition-colors text-lg" data-index="${index}">×</button>
      `;
      mappingList.appendChild(row);
    });

    document.querySelectorAll('.delete-map-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = e.target.getAttribute('data-index');
        currentMappings.splice(idx, 1);
        chrome.storage.sync.set({ [storageKey]: currentMappings });
        renderMappings();
      });
    });

    document.getElementById('showSaveTemplateBtn').classList.remove('hidden');
  }

  // --- Template UI Logic ---
  const showSaveBtn = document.getElementById('showSaveTemplateBtn');
  const saveForm = document.getElementById('saveTemplateForm');
  const templateNameInput = document.getElementById('templateNameInput');

  showSaveBtn.addEventListener('click', () => {
    showSaveBtn.classList.add('hidden');
    saveForm.classList.remove('hidden');
    saveForm.classList.add('flex');
    templateNameInput.focus();
  });

  document.getElementById('cancelSaveTemplateBtn').addEventListener('click', () => {
    saveForm.classList.add('hidden');
    saveForm.classList.remove('flex');
    showSaveBtn.classList.remove('hidden');
    templateNameInput.value = '';
  });

  document.getElementById('confirmSaveTemplateBtn').addEventListener('click', async () => {
    const name = templateNameInput.value.trim();
    if (!name) return alert("Enter a template name");
    
    await StorageManager.saveTemplate(name, currentMappings);
    
    saveForm.classList.add('hidden');
    saveForm.classList.remove('flex');
    showSaveBtn.classList.remove('hidden');
    templateNameInput.value = '';
    
    renderTemplatesList();
    alert("Template saved globally!");
  });

  async function renderTemplatesList() {
    const templates = await StorageManager.getTemplates();
    const list = document.getElementById('templateList');
    
    if (templates.length === 0) {
      list.innerHTML = '<p class="text-xs text-center text-slate-400 italic mt-4">No templates saved.</p>';
      return;
    }

    list.innerHTML = '';
    templates.forEach(t => {
      const li = document.createElement('li');
      li.className = "flex flex-col bg-white p-3 rounded-md border border-slate-200 shadow-sm gap-2";
      li.innerHTML = `
        <div class="flex justify-between items-center border-b border-slate-100 pb-1">
          <span class="font-bold text-slate-700">${t.name}</span>
          <span class="text-xs bg-violet-100 text-violet-800 px-2 rounded-full">${t.mappings.length} fields</span>
        </div>
        <div class="flex gap-2 mt-1">
          <button class="flex-1 bg-violet-50 text-violet-700 border border-violet-200 py-1 rounded text-xs font-medium hover:bg-violet-100 load-tpl-btn" data-id="${t.id}">Apply to this Site</button>
          <button class="bg-red-50 text-red-600 border border-red-200 px-3 py-1 rounded text-xs hover:bg-red-100 del-tpl-btn" data-id="${t.id}">Delete</button>
        </div>
      `;
      list.appendChild(li);
    });

    document.querySelectorAll('.load-tpl-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const id = e.target.getAttribute('data-id');
        const tpl = templates.find(x => x.id === id);
        if (tpl && storageKey) {
          currentMappings = tpl.mappings; 
          chrome.storage.sync.set({ [storageKey]: currentMappings });
          renderMappings();
          syncHeadersWithMappings();
          document.querySelector('[data-target="mapping"]').click(); 
        }
      });
    });

    document.querySelectorAll('.del-tpl-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        if(confirm("Delete this template?")) {
          const id = e.target.getAttribute('data-id');
          await StorageManager.deleteTemplate(id);
          renderTemplatesList();
        }
      });
    });
  }

  // --- Export / Import UI Logic ---
  document.getElementById('exportDataBtn').addEventListener('click', () => {
    StorageManager.exportAllData();
  });

  document.getElementById('importDataBtn').addEventListener('click', () => {
    document.getElementById('importFileInput').click();
  });

  document.getElementById('importFileInput').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        // Verify it's actually valid JSON before trusting it
        const parsedData = JSON.parse(event.target.result);
        
        if (typeof parsedData !== 'object' || parsedData === null) {
            throw new Error("Invalid format");
        }

        StorageManager.importData(event.target.result, (success) => {
          if (success) {
            alert("Data imported successfully!");
            initSiteContext();
            renderTemplatesList();
          } else {
            alert("Could not merge backup file. Data may be corrupted.");
          }
        });
      } catch (error) {
          alert("Invalid backup file. Please ensure you are uploading a valid FormFlow JSON export.");
      }
      e.target.value = ''; 
    };
    reader.readAsText(file);
  });

 // ==========================================
  // INITIALIZATION ON POPUP OPEN
  // ==========================================
  chrome.storage.local.get(['activeTable', 'activeHeaders', 'fileName', 'savedRowIndex'], (result) => {
    if (result.activeTable && result.activeHeaders) {
      currentData = result.activeTable;
      currentHeaders = result.activeHeaders;
      document.getElementById('dropZone').classList.add('hidden');
      renderPreviewTable(result.fileName || 'Restored Table', currentHeaders, currentData);
      
      // Load saved row index
      if (result.savedRowIndex !== undefined) {
        currentRowIndex = result.savedRowIndex;
      }
      updateRowUI();
    }
  });

  initSiteContext();
  renderTemplatesList();

  // ==========================================
  // 4. AUTO-FILL CONTROLLER LOGIC
  // ==========================================
  let currentRowIndex = 0;
  
  const rowDisplay = document.getElementById('rowDisplay');
  const jumpRowInput = document.getElementById('jumpRowInput');

  function updateRowUI() {
    if (!currentData || currentData.length === 0) {
      rowDisplay.textContent = "No Data";
      return;
    }
    // Humans read 1-indexed, arrays are 0-indexed
    rowDisplay.textContent = `Row ${currentRowIndex + 1} of ${currentData.length}`;
    jumpRowInput.value = currentRowIndex + 1;
    jumpRowInput.max = currentData.length;
    
    // Save state so popup remembers if closed
    chrome.storage.local.set({ savedRowIndex: currentRowIndex });
  }

  // --- Core Actions ---
  // --- Launch Player Action ---
  document.getElementById('fillCurrentBtn').addEventListener('click', async () => {
    if (!currentData || currentMappings.length === 0) {
      return alert("Please upload data and map fields first.");
    }

    // Activate the session in Chrome Storage
    chrome.storage.local.set({
      ff_session_active: true,
      savedRowIndex: currentRowIndex
    }, async () => {
      // Send the launch command to the webpage
      const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
      chrome.tabs.sendMessage(tab.id, {
        action: "START_PLAYER",
        data: currentData,
        rowIndex: currentRowIndex,
        mappings: currentMappings
      });
      
      // Close the popup instantly to reveal the player
      window.close(); 
    });
  });

  document.getElementById('prevRowBtn').addEventListener('click', () => {
    if (!currentData) return;
    if (currentRowIndex > 0) {
      currentRowIndex--;
      updateRowUI();
    }
  });

  document.getElementById('nextRowBtn').addEventListener('click', () => {
    if (!currentData) return;
    if (currentRowIndex < currentData.length - 1) {
      currentRowIndex++;
      updateRowUI();
    }
  });

  document.getElementById('jumpRowBtn').addEventListener('click', () => {
    if (!currentData) return;
    let target = parseInt(jumpRowInput.value, 10);
    if (isNaN(target) || target < 1) target = 1;
    if (target > currentData.length) target = currentData.length;
    
    currentRowIndex = target - 1;
    updateRowUI();
  });

  // --- Launch AUTO Mode ---
  document.getElementById('startAutoModeBtn').addEventListener('click', async () => {
    if (!currentData || currentMappings.length === 0) {
      return alert("Please upload data and map fields first.");
    }

    if (!confirm("WARNING: Auto-pilot will rapidly fill and submit forms until complete or stopped. Ensure your mapping is correct before proceeding. Ready?")) {
      return;
    }

    const delay = parseFloat(document.getElementById('autoDelayInput').value) || 2.0;
    const maxRows = parseInt(document.getElementById('maxRowsInput').value) || 0;
    const stopIndex = maxRows > 0 ? currentRowIndex + maxRows : currentData.length;

    // Save Auto-Mode state to Chrome Storage so it survives page reloads!
    chrome.storage.local.set({
      ff_session_active: true,
      ff_auto_mode: true,            // FIXED: Must be true to survive page reloads!
      ff_auto_delay: delay,
      ff_auto_stop_index: stopIndex,
      savedRowIndex: currentRowIndex
    }, async () => {
      
      const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
      const startMessage = {
        action: "START_AUTO_PLAYER", // Matches Section 10 in content.js
        data: currentData,
        rowIndex: currentRowIndex,
        mappings: currentMappings,
        delay: delay
      };

      // Auto-Inject safety net
      chrome.tabs.sendMessage(tab.id, startMessage, () => {
        if (chrome.runtime.lastError) {
          chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/content.js"] })
            .then(() => {
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, startMessage);
                window.close();
              }, 100);
            });
        } else {
          window.close(); 
        }
      });
    });
  });

  document.getElementById('clearFormBtn').addEventListener('click', async () => {
    if (currentMappings.length === 0) return;
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    chrome.tabs.sendMessage(tab.id, {
      action: "CLEAR_FORM",
      mappings: currentMappings
    });
  });
  initSiteContext();
  renderTemplatesList();

}); // End DOMContentLoaded